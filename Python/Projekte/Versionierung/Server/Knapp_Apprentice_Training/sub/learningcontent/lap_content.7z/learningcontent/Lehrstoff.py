# -*- coding: utf-8 -*-

"""
Module implementing Lehrstoff.
"""
from sub.XML.XML_Class import DBtoXML 
from PyQt5 import *
from PyQt5.QtCore import pyqtSlot,  Qt
from PyQt5.QtWidgets import  *
from other.database import Database
from tkinter import messagebox
import tkinter as tk

from sub.learningcontent.Ui_Lehrstoff import Ui_Dialog



class Lehrstoff(QDialog, Ui_Dialog):
    """
    Class documentation goes here.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget
        @type QWidget
        """
        super(Lehrstoff, self).__init__(parent)
        self.setupUi(self)
        self.combobox_befüllen()
        self.tW_Datenbank_Anzeigen()
       
    def combobox_befüllen(self):
        """
        Methode für das Befüllen der Combobox aus den Datenbanktabellen apprentice_fachgebiete und
        apprentice_ausbilder
        """
        #befüllen der ComboBox "cB_Fachgebiet" aus der DB apprentice_fachgebiete
        db = Database.get_instance(self)
        sql = "SELECT apprentice_fachgebiete.Fachgebiet FROM apprentice_fachgebiete"
        mycursor = db.select(sql)
        rows = mycursor.fetchall()
        if mycursor == "backtologin":
            self.back_to_login()
            return
        self.cB_Fachgebiet.addItem("Alle Anzeigen")
        for i in rows:
            self.cB_Fachgebiet.addItem(i[0])
            
         #befüllen der ComboBox "cB_Verantwortlicher" aus der DB apprentice_ausbilder
        sql = "SELECT apprentice_ausbilder.Familienname FROM apprentice_ausbilder"
        mycursor = db.select(sql)
        rows2 = mycursor.fetchall()
        if mycursor == "backtologin":
            self.back_to_login()
            return
            
        self.cB_Verantwortlicher.addItem("Alle Anzeigen")
        for i in rows2:
            self.cB_Verantwortlicher.addItem(i[0])
        
    @pyqtSlot()
    def on_pB_Abbrechen_clicked(self):
        """
        Methode um Lehrstofffenster zu schließen und Hauptmenufenster zu öffnen
        """
        self.parent().show()
        self.close()
    
    @pyqtSlot()
    def on_pB_Speichern_clicked(self):
        """
        Methode um DB-Tabelle apprentice_lehrstoff zu befüllen oder zu aktualisieren
        """
        
        #datentabelle befüllen
        db = Database.get_instance(self)
        sql =  "select * from apprentice_lehrstoff WHERE Fachgebiet = '" + self.cB_Fachgebiet.currentText() + "' AND LehrstoffID = '" +self.le_Lehrstoff_ID.text()+"'"
        mycursor = db.select(sql)
        
        if mycursor == "backtologin":
            self.back_to_login()
            return
        
        sql_satz = []
        sql_satz =  mycursor.fetchall()
        satz_len = len(sql_satz)
        
        if satz_len == 0:
            print("insert")
            sql = "INSERT INTO apprentice_lehrstoff (Fachgebiet, LehrstoffID, Verantwortlicher, Bezeichnung, Dokument, Stunden, Hilfsmittel, Benutzer) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            val = (self.cB_Fachgebiet.currentText(),  self.le_Lehrstoff_ID.text(), self.cB_Verantwortlicher.currentText(),   self.le_Bezeichnung.text(),  self.le_Dokument.text(),  self.sB_Stunden.value(), self.le_Hilfsmittel.text(),  self.parent().label_eingeloggt_als.text())
            self.INFO("Eintrag wurde in die Datenbank gespeichert",  "I")

        else:
            print("update")
            sql = "UPDATE apprentice_lehrstoff set Verantwortlicher=%s, Bezeichnung=%s, Dokument=%s, Stunden=%s, Hilfsmittel=%s, Benutzer=%s" + " where Fachgebiet='" + self.cB_Fachgebiet.currentText() + "' AND LehrstoffID='" + self.le_Lehrstoff_ID.text()+"'"
            val = (self.cB_Verantwortlicher.currentText(),  self.le_Bezeichnung.text(),  self.le_Dokument.text(),  self.sB_Stunden.value(), self.le_Hilfsmittel.text(),   self.parent().label_eingeloggt_als.text())
            self.INFO("Eintrag wurde in der Datenbank aktualisiert." ,  "I")

        db.insert(sql, val)
        self.tW_Datenbank_Anzeigen()

    @pyqtSlot()
    def on_pB_Loeschen_clicked(self):
        """
        Methode um ausgewählte Zeile aus DB-Tabelle zu löschen
        """
        db = Database.get_instance(self)
        sql = "DELETE FROM apprentice_lehrstoff WHERE Fachgebiet='" + self.cB_Fachgebiet.currentText()+ "'AND LehrstoffID = '" + self.le_Lehrstoff_ID.text() + "'"
        db.delete(sql)
        self.tW_Datenbank_Anzeigen()
        self.INFO("Ausgewählter Eintrag wurde aus der Datenbank gelöscht.",  "I")
        
    
    @pyqtSlot()
    def on_pB_Hilfe_clicked(self):
        """
        Slot documentation goes here
        """
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Hilfe",  "Die Hilfe-Funktion wird in kürze hinzugefügt!")
        
    
    @pyqtSlot(int, int)
    def on_tW_Datenbank_cellClicked(self, row, column):
        """
        Methode um alle Lineedit, Comboboxen, etc. mit den ausgewählten werten zu befüllen.
        """
        #QApplication.setOverridemycursor(Qmycursor(Qt.Waitmycursor))
        
        self.cB_Fachgebiet.setCurrentText(self.tW_Datenbank.item(row, 1).text())
        self.le_Lehrstoff_ID.setText(self.tW_Datenbank.item(row, 2).text())
        self.cB_Verantwortlicher.setCurrentText(self.tW_Datenbank.item(row, 3).text())
        self.le_Bezeichnung.setText(self.tW_Datenbank.item(row, 4).text())
        self.le_Dokument.setText(self.tW_Datenbank.item(row, 5).text())
        self.sB_Stunden.setValue(int(self.tW_Datenbank.item(row, 6).text()))
        self.le_Hilfsmittel.setText(self.tW_Datenbank.item(row, 7).text())
        
        
    def tW_Datenbank_Anzeigen(self, filter1 = "",  filter2 = ""):
        """
        Methode um das Tablewidget aus der DB-Tabelle apprentice_lehrstoff zu befüllen
        """
        self.setCursor(Qt.WaitCursor)
        db = Database.get_instance(self)
        #überschriften setzen
        self.tW_Datenbank.setColumnCount(10)
        colfachgebiet = QTableWidgetItem("ID")
        self.tW_Datenbank.setHorizontalHeaderItem(0, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Fachgebiet")
        self.tW_Datenbank.setHorizontalHeaderItem(1, colfachgebiet)
        colfachgebiet = QTableWidgetItem("LehrstoffID")
        self.tW_Datenbank.setHorizontalHeaderItem(2, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Verantwortlicher")
        self.tW_Datenbank.setHorizontalHeaderItem(3, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Bezeichnung")
        self.tW_Datenbank.setHorizontalHeaderItem(4, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Dokument")
        self.tW_Datenbank.setHorizontalHeaderItem(5, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Stunden")
        self.tW_Datenbank.setHorizontalHeaderItem(6, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Hilfsmittel")
        self.tW_Datenbank.setHorizontalHeaderItem(7, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Benutzer")
        self.tW_Datenbank.setHorizontalHeaderItem(8, colfachgebiet)
        colfachgebiet = QTableWidgetItem("Änderung")
        self.tW_Datenbank.setHorizontalHeaderItem(9, colfachgebiet)
        
        self.tW_Datenbank.setRowCount(1)
        if filter2 == "Alle Anzeigen":
            filter2 = ""
        if filter2 != "":
            print(filter2)
            sql =  "select * from apprentice_lehrstoff WHERE "+ filter1 +" = '" + filter2 + "'"
        else:
            sql = "select * from apprentice_lehrstoff"
            
        mycursor = db.select(sql)
        if mycursor == "backtologin":
            self.back_to_login()
            return
        zeile = 0 
     
        for z in mycursor:
            for s in range(0,  10):
                self.tW_Datenbank.setRowCount(zeile + 1)
                fielditem = QTableWidgetItem(str(z[s]))
                self.tW_Datenbank.setItem(zeile,  s,  fielditem)
            zeile+=1
                
        mycursor.close()
        
        self.tW_Datenbank.resizeColumnsToContents()
        self.tW_Datenbank.resizeRowsToContents()
        self.setCursor(Qt.ArrowCursor)
    
    @pyqtSlot()
    def on_pB_Suchen_clicked(self):
        """
        Slot documentation goes here
        """
        
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Hilfe",  "Die Suche-Funktion wird in kürze hinzugefügt!")
    
    @pyqtSlot()
    def on_tB_Dokument_Suchen_clicked(self):
        """
        Methode um ein Dokument aus einer Directory (Explorer-Suche) einzfügen
        """
        dokument = str(QtWidgets.QFileDialog.getOpenFileName(self))
        self.le_Dokument.setText(dokument)
        self.INFO("Dokument wurde eingefügt.",  "H")
        
    def back_to_login(self):
        """
        Methode um bei Verbindungsabbruch zur DB 
        """
        self.parent().back_to_login()
        self.close()
        
    @pyqtSlot()
    def on_pB_Excel_clicked(self):
        """
        Methode um HTML Datei zu erstellen
        """
        db = Database.get_instance(self)
        DBtoXML.MakeXML(db, "apprentice_lehrstoff")
        self.INFO("Excel-Datei wurde erstellt.",  "I")

    @pyqtSlot()
    def on_pB_Report_clicked(self):
        """
        Methode um HTML Datei zu erstellen
        """
        db = Database.get_instance(self)
        DBtoXML.MakeXML(db, "apprentice_lehrstoff")
        self.INFO("PDF-Datei wurde erstellt.",  "I")
    
    @pyqtSlot(str)
    def on_cB_Fachgebiet_currentTextChanged(self, p0):
        """
        Slot documentation goes here.
        
        @param p0 DESCRIPTION
        @type str
        """
        if p0 == "Alle Anzeigen":
            self.cB_Fachgebiet.setCurrentText("Alle Anzeigen")
            self.le_Lehrstoff_ID.setText("")
            self.cB_Verantwortlicher.setCurrentText("Alle Anzeigen")
            self.le_Bezeichnung.setText("")
            self.le_Dokument.setText("")
            self.sB_Stunden.setValue(0)
            self.le_Hilfsmittel.setText("")
        self.tW_Datenbank_Anzeigen("Fachgebiet", p0)
    
    @pyqtSlot(str)
    def on_cB_Verantwortlicher_currentTextChanged(self, p0):
        """
        Slot documentation goes here.
        
        @param p0 DESCRIPTION
        @type str
        """
        if p0 == "Alle Anzeigen":
            self.cB_Fachgebiet.setCurrentText("Alle Anzeigen")
            self.le_Lehrstoff_ID.setText("")
            self.cB_Verantwortlicher.setCurrentText("Alle Anzeigen")
            self.le_Bezeichnung.setText("")
            self.le_Dokument.setText("")
            self.sB_Stunden.setValue(0)
            self.le_Hilfsmittel.setText("")
        self.tW_Datenbank_Anzeigen("Verantwortlicher", p0)

    def INFO(self,  MELDUNG,  INFO_STAT): #Zentrale Ausgabe von Infos/Meldungen
        self.lab_INFO.setText(MELDUNG) #Text aus MELDUNG übernehmen und ausgeben
        if INFO_STAT == "F": #Fehler
            self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(255,0,0) }")
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Fehler", MELDUNG)
        else:
            if INFO_STAT == "H": #Hinweis
                self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(255,197,20) }")
                root = tk.Tk()
                root.withdraw()
                messagebox.showwarning("Hinweis/Warnung", MELDUNG)
            else:
                self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(85,170,127) }")
