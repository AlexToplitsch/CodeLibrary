# -*- coding: utf-8 -*-

"""
Module implementing Themenkatalog.
"""
from sub.XML.XML_Class import DBtoXML
from PyQt5.QtCore import pyqtSlot,  Qt
from PyQt5.QtWidgets import QDialog,  QTableWidgetItem
from other.database import Database
import tkinter as tk
from tkinter import messagebox
    
from sub.lapcontent.Ui_LAP_Themenkatalog import Ui_Dialog_Themenkatalog

class Themenkatalog(QDialog, Ui_Dialog_Themenkatalog):
    """
    Class documentation goes here.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget
        @type QWidget
        """
        super(Themenkatalog, self).__init__(parent)
        self.setupUi(self)
        self.combobox_befüllen()
        self.tW_Db_Themenkatalog_Anzeigen()
        
    def combobox_befüllen(self):
        """
        Methode für das Befüllen der Combobox aus den Datenbanktabellen apprentice_fachrichtungen und
        apprentice_ausbilder
        """
         #befüllen der ComboBox "cB_Fachrichtung" aus der DB apprentice_fachrichtungen
        db = Database.get_instance(self)
        sql = "SELECT apprentice_fachrichtungen.Bezeichnung FROM apprentice_fachrichtungen"
        mycursor = db.select(sql)
        
        if mycursor == "backtologin":
            self.back_to_login()
            return
            
        rows = mycursor.fetchall()
        self.cB_Fachrichtung.addItem("Alle Anzeigen")
        for i in rows:
            self.cB_Fachrichtung.addItem(i[0])
        
        #befüllen der ComboBox "cB_Ausbilder" aus der DB apprentice_ausbilder
        sql = "SELECT apprentice_ausbilder.Familienname FROM apprentice_ausbilder"
        mycursor = db.select(sql)
        if mycursor == "backtologin":
            self.back_to_login()
            return
        rows = mycursor.fetchall()
        self.cB_Ausbilder.addItem("Alle Anzeigen")
        for i in rows:
            self.cB_Ausbilder.addItem(i[0])
        
    @pyqtSlot()
    def on_pB_Hilfe_clicked(self):
        """
        Slot documentation goes here
        """
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Hilfe",  "Die Hilfe-Funktion wird in kürze hinzugefügt!")
    
    @pyqtSlot()
    def on_pB_Abbrechen_clicked(self):
        """
        Methode um Lehrstofffenster zu schließen und Hauptmenufenster zu öffnen
        """
        self.parent().show()
        self.close()
    
    @pyqtSlot(int, int)
    def on_tW_Db_Themenkatalog_cellClicked(self, row, column):
        """
        Methode um das Tablewidget aus der DB-Tabelle apprentice_lap_themenkatalog zu befüllen
        """
        #QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        
        self.cB_Fachrichtung.setCurrentText(self.tW_Db_Themenkatalog.item(row, 1).text())
        self.le_Themen_ID.setText(self.tW_Db_Themenkatalog.item(row, 2).text())
        self.le_Thema.setText(self.tW_Db_Themenkatalog.item(row, 3).text())
        self.cB_Ausbilder.setCurrentText(self.tW_Db_Themenkatalog.item(row, 4).text())
        self.sB_Lehrjahr.setValue(int(self.tW_Db_Themenkatalog.item(row, 5).text()))
        self.sB_BS_Jahr.setValue(int(self.tW_Db_Themenkatalog.item(row, 6).text()))
    
    @pyqtSlot()
    def on_pB_Speichern_clicked(self):
        """
        Methode um DB-Tabelle apprentice_lap_themenkatalog zu befüllen oder zu aktualisieren
        """
        #datentabelle befüllen
        db = Database.get_instance(self)
        sql = "select * from apprentice_lap_themenkatalog WHERE Fachrichtung = '" + self.cB_Fachrichtung.currentText() + "' AND Themen_ID = '" + self.le_Themen_ID.text() + "'"
        mycursor = db.select(sql)
        
        if mycursor == "backtologin":
            self.back_to_login()
            return
            
        sql_satz = mycursor.fetchall()
        satz_len = len(sql_satz)
        if satz_len == 0:
            print("insert")
            sql = "INSERT INTO apprentice_lap_themenkatalog (Fachrichtung,Themen_ID, Thema, Ausbilder, Lehrjahr, BS_Lehrjahr, Benutzer) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            val = (self.cB_Fachrichtung.currentText(),  self.le_Themen_ID.text(),  self.le_Thema.text(),  self.cB_Ausbilder.currentText(),  self.sB_Lehrjahr.value(), self.sB_BS_Jahr.value(), self.parent().label_eingeloggt_als.text())
            self.INFO("Eintrag wurde in die Datenbank gespeichert",  "I")
        else:
            print("update")
            sql = "UPDATE apprentice_lap_themenkatalog set Thema=%s, Ausbilder=%s, Lehrjahr=%s, BS_Lehrjahr=%s, Benutzer=%s" + " WHERE Fachrichtung = '" + self.cB_Fachrichtung.currentText() + "' AND Themen_ID = '" + self.le_Themen_ID.text() + "'"
            val = (self.le_Thema.text(),  self.cB_Ausbilder.currentText(),  self.sB_Lehrjahr.value(), self.sB_BS_Jahr.value(), self.parent().label_eingeloggt_als.text())
            self.INFO("Eintrag wurde in der Datenbank aktualisiert." ,  "I")

        mycursor = db.insert(sql, val)
        if mycursor == "backtologin":
            self.back_to_login()
            return
        self.tW_Db_Themenkatalog_Anzeigen()
    
    @pyqtSlot()
    def on_pB_Suchen_clicked(self):
        """
        Slot documentation goes here
        """
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Hilfe",  "Die Suche-Funktion wird in kürze hinzugefügt!")
    
    @pyqtSlot()
    def on_pB_Loeschen_clicked(self):
        """
        Methode um ausgewählte Zeile aus DB-Tabelle zu löschen
        """
        db = Database.get_instance(self)
        sql = "DELETE FROM apprentice_lap_themenkatalog WHERE Fachrichtung='" + self.cB_Fachrichtung.currentText()+ "'AND Themen_ID = '" + self.le_Themen_ID.text() + "'"
        mycursor = db.delete(sql)
        if mycursor == "backtologin":
            self.back_to_login()
            return
        self.tW_Db_Themenkatalog_Anzeigen()
        self.INFO("Ausgewählter Eintrag wurde aus der Datenbank gelöscht.",  "I")
        
        
        
    def tW_Db_Themenkatalog_Anzeigen(self,  filter1 = "",  filter2 = ""):
        self.setCursor(Qt.WaitCursor)
        
        #überschriften setzen
        self.tW_Db_Themenkatalog.setColumnCount(9)
        colname = QTableWidgetItem("ID")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(0, colname)
        colname = QTableWidgetItem("Fachrichtung")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(1, colname)
        colname = QTableWidgetItem("Themen_ID")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(2, colname)
        colname = QTableWidgetItem("Thema")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(3, colname)
        colname = QTableWidgetItem("Ausbilder")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(4, colname)
        colname = QTableWidgetItem("Lehrjahr")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(5, colname)
        colname = QTableWidgetItem("BS_Lehrjahr")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(6, colname)
        colname = QTableWidgetItem("Benutzer")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(7, colname)
        colname = QTableWidgetItem("Änderung")
        self.tW_Db_Themenkatalog.setHorizontalHeaderItem(8, colname)
        
        self.tW_Db_Themenkatalog.setRowCount(1)
        
        db = Database.get_instance(self)
        if filter2 == "Alle Anzeigne":
            filter2 = ""
        if filter2 != "":
            sql =  "select * from apprentice_lap_themenkatalog WHERE "+ filter1 +" = '" + filter2 + "'"
        else:
            sql = "select * from apprentice_lap_themenkatalog"
        mycursor = db.select(sql)
        if mycursor == "backtologin":
            self.back_to_login()
            return
        
        zeile = 0 
        for z in mycursor:
            for s in range(0,  9):
                self.tW_Db_Themenkatalog.setRowCount(zeile + 1)
                fielditem = QTableWidgetItem(str(z[s]))
                self.tW_Db_Themenkatalog.setItem(zeile,  s,  fielditem)
            zeile+=1
                
        mycursor.close()
        
        self.tW_Db_Themenkatalog.resizeColumnsToContents()
        self.tW_Db_Themenkatalog.resizeRowsToContents()
        self.setCursor(Qt.ArrowCursor)
    
    def back_to_login(self):
        self.parent().back_to_login()
        self.close()
    
    @pyqtSlot(str)
    def on_cB_Fachrichtung_currentTextChanged(self, p0):
        if p0 == "Alle Anzeigen":
            self.cB_Fachrichtung.setCurrentText("Alle Anzeigen")
            self.le_Themen_ID.setText("")
            self.le_Thema.setText("")
            self.cB_Ausbilder.setCurrentText("Alle Anzeigen")
            self.sB_Lehrjahr.setValue(0)
            self.sB_BS_Jahr.setValue(0)
            
        self.tW_Db_Themenkatalog_Anzeigen("Fachrichtung",  p0)
    
    @pyqtSlot(str)
    def on_cB_Ausbilder_currentTextChanged(self, p0):
        if p0 == "Alle Anzeigen":
            self.cB_Fachrichtung.setCurrentText("Alle Anzeigen")
            self.le_Themen_ID.setText("")
            self.le_Thema.setText("")
            self.cB_Ausbilder.setCurrentText("Alle Anzeigen")
            self.sB_Lehrjahr.setValue(0)
            self.sB_BS_Jahr.setValue(0)
    
        self.tW_Db_Themenkatalog_Anzeigen("Ausbilder",  p0)
    
    @pyqtSlot()
    def on_pB_Report_clicked(self):
        db = Database.get_instance(self)
        DBtoXML.MakeXML(db, "apprentice_lap_themenkatalog")
        self.INFO("PDF-Datei wurde erstellt.",  "I")
    
    @pyqtSlot()
    def on_pB_Excel_clicked(self):
        db = Database.get_instance(self)
        DBtoXML.MakeXML(db, "apprentice_lap_themenkatalog")
        self.INFO("Excel-Datei wurde erstellt.",  "I")
    
    def INFO(self,  MELDUNG,  INFO_STAT): #Zentrale Ausgabe von Infos/Meldungen
        self.lab_INFO.setText(MELDUNG) #Text aus MELDUNG übernehmen und ausgeben
        if INFO_STAT == "F": #Fehler
            self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(255,0,0) }")
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Fehler", MELDUNG)
        else:
            if INFO_STAT == "H": #Hinweis
                self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(255,197,20) }")
                root = tk.Tk()
                root.withdraw()
                messagebox.showwarning("Hinweis/Warnung", MELDUNG)
            else:
                self.lab_INFO.setStyleSheet("QLabel { background-color : rgb(85,170,127) }")
